package codes.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import codes.DAO.StaffDAO;
import codes.Model.Staff;

@Controller
public class BaseController {

	@Autowired
	StaffDAO sd;
	
	@ModelAttribute("staffobj")
	public Staff getStaff(){
		return new Staff();
	}
	
	@RequestMapping("/")
	public String gohome(){
		return "home";
	}
	
	@RequestMapping("/reg")
	public String goRegister(){
		return "register";
	}
	
	@RequestMapping("/save")
	public String goSave(@ModelAttribute("staffobj")Staff x){
		sd.addStaff(x);
		return "home";
	}
	
	@RequestMapping("/view")
	public ModelAndView viewUser(){
		ModelAndView m = new ModelAndView("viewUser");
		m.addObject("data", sd.viewAllStaffs());
		return m;
	}
}
