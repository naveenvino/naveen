package productstore.Controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

@Controller
public class LoginController {
	
        @RequestMapping("/header")
        public String profile() {
        System.out.println("header");
        return "header";
        }

        
        @RequestMapping("/")
        public String profile1() {
        System.out.println("login");
        return "login";
        }

    
}

