package productstore.DAO;

import java.util.List;

import org.hibernate.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import productstore.Model.Product;

@Repository
public class ProductDaoImplement implements ProductDAO {

	@Autowired
	SessionFactory sf;
	
	Session s;
	Transaction t;
	Product obj;
	
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		s.save(p);
		t.commit();
	}

	public void delProduct(int id) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		s.delete(id);
		t.commit();
	}

	public void updProduct(Product p) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		Product x = (Product)s.load(Product.class, p.getPid());
		x.setPname(p.getPname());
		x.setPrice(p.getPrice());
		x.setQuantity(p.getQuantity());
		s.saveOrUpdate(x);
		t.commit();
		
	}

	public Product viewById(int id) {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		obj = (Product)s.load(Product.class, id);
		t.commit();
		return obj;
	}

	public List<Product> viewAll() {
		// TODO Auto-generated method stub
		s = sf.openSession();
		t = s.beginTransaction();
		List<Product> l = s.createCriteria(Product.class).list();
		t.commit();
		return l;
	}

}

