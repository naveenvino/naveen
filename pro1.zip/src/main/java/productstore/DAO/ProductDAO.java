package productstore.DAO;


import java.util.List;

import productstore.Model.Product;

public interface ProductDAO {

	void addProduct(Product p);
	void delProduct(int id);
	void updProduct(Product p);
	Product viewById(int id);
	List<Product> viewAll();
}


