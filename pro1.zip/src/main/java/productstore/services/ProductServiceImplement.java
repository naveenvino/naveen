package productstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import productstore.DAO.ProductDAO;
import productstore.Model.Product;

@Service
public class ProductServiceImplement implements ProductService {

	@Autowired
	ProductDAO pd;
	
	public void addProduct(Product p) {
		// TODO Auto-generated method stub
		pd.addProduct(p);
	}

	public void delProduct(int id) {
		// TODO Auto-generated method stub
		pd.delProduct(id);
	}

	public void updProduct(Product p) {
		// TODO Auto-generated method stub
		pd.updProduct(p);
	}

	public Product viewById(int id) {
		// TODO Auto-generated method stub
		return pd.viewById(id);
	}

	public List<Product> viewAll() {
		// TODO Auto-generated method stub
		return pd.viewAll();
	}

}


