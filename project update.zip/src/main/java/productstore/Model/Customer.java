package productstore.Model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;

import com.sun.istack.internal.NotNull;



@Entity
public class Customer {
	@Size(min=5,max=10)
	@NotNull
	@Id
	private String username;

	@NotNull
   
	@Email
	@Column
	private String email;
	@NotNull
	@Column
	private String userpassword;
	@NotNull
	@Column
	private String confirmpassword;
	@Column
	private String role="ROLE_USER";
	@Column
	private boolean enable=true;

	
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	public String getConfirmpassword() {
		return confirmpassword;
	}
	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpassword() {
		return userpassword;
	}
	public void setUserpassword(String userpassword) {
		this.userpassword = userpassword;
	}

}

