package productstore.DAO;
 import java.util.List;
import productstore.Model.Customer;

public interface CustomerDao {
	void addCustomer(Customer c);
	void delCustomer(String username);
	void saveorupdCustomer(Customer p);
	Customer viewById(String username);
	List<Customer> viewAllCustomers();
 
}
