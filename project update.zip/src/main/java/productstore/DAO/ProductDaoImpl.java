package productstore.DAO;

import java.util.List;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import productstore.Model.Product;
@Repository
public class ProductDaoImpl implements ProductDao {

	@Autowired
	SessionFactory sf1;
	
	Session s1;
	Transaction t1;
	Product obj1;
	

	@Override
	public void addProduct(Product c) {
		// TODO Auto-generated method stub
		s1 = sf1.openSession();
		t1 = s1.beginTransaction();
		s1.save(c);  
		t1.commit();
	}

	@Override
	public void delProduct(int productid) {
		// TODO Auto-generated method stub
		s1 = sf1.openSession();
		t1 = s1.beginTransaction();
		Product x2 = (Product)s1.load(Product.class,productid);
		s1.delete(x2);
		t1.commit();

	}

	@Override
	public void saveorupdProduct(Product p) {
		// TODO Auto-generated method stub
		/*s1 = sf1.openSession();
		t1 = s1.beginTransaction();
		Product x2 = (Product)s1.load(Product.class,p.getProductid());
		x2.setProductname(p.getProductname());
		x2.setProductquantity(p.getProductquantity());
		x2.setProductprice(p.getProductprice());
		x2.setProductdescription(p.getProductdescription());
		s1.saveOrUpdate(x2);
		t1.commit();*/


	}

	@Override
	public Product viewById(int productid) {
		// TODO Auto-generated method stub

		s1 = sf1.openSession();
		t1 = s1.beginTransaction();
		Product x2 = (Product)s1.load(Product.class,productid);
		t1.commit();
		return x2;

	}

	@Override
	public List<Product> viewAllProduct() {
		// TODO Auto-generated method stub
		s1 = sf1.openSession();
		t1 = s1.beginTransaction();
		List<Product> l1 = s1.createCriteria(Product.class).list();
		t1.commit();
		return l1;
	
	}

}
