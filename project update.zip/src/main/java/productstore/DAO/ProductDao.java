
package productstore.DAO;

import java.util.List;

import productstore.Model.Product;

public interface ProductDao {
	void addProduct(Product c);
	void delProduct(int productid);
	void saveorupdProduct(Product p);
	Product viewById(int productid);
	List<Product> viewAllProduct();

}
