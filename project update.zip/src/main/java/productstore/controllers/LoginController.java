package productstore.controllers;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import productstore.DAO.CustomerDao;
import productstore.DAO.ProductDao;
import productstore.Model.Customer;
import productstore.Model.Product;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;

@Controller
public class LoginController {
		
	   
		
	     @Autowired
			ProductDao pd;
		
	     @ModelAttribute("probj")
			public 	Product getproduct(){
				return new 	Product();
			}
	     
	     @RequestMapping("/product")
			public String Product() {
			System.out.println("product");
			return "product";
			}
	     @RequestMapping("/prosave")
			public String goproSave(@ModelAttribute("probj")Product x,HttpServletRequest req){
				System.out.println("In proSave");
				pd.addProduct(x);
				
				MultipartFile itemImage = x.getFile();
		        String rootDirectory = req.getSession().getServletContext().getRealPath("/");
		        File f = new File(rootDirectory + "resources\\images\\");
		        if(!f.exists())
		        	f.mkdirs(); 
		        Path path = Paths.get(rootDirectory + "resources\\images\\"+x.getProductid()+".jpg");
		        
		        if (itemImage != null && !itemImage.isEmpty()) {
		            try {
		            	itemImage.transferTo(new File(path.toString()));
		            	System.out.println("Image Uploaded - "+rootDirectory + "resources\\images\\"+x.getProductid()+".jpg");
		            } catch (Exception e) {
		                e.printStackTrace();
		                throw new RuntimeException("item image saving failed.", e);
		            }
		        }	
				
				return "redirect:/product";
			}
	     
	     @RequestMapping("/addproduct")
	        public String addproduct() {
	        System.out.println("addproduct");
	        return "addproduct";
	        }
	     /*   @RequestMapping("/viewallproduct")
	    	public ModelAndView goviewproducts() {
	    	System.out.println("viewproduct");
	       ModelAndView view=new ModelAndView("viewallproduct");
	    	view.addObject("data", pd.viewAllProduct());	
	    	return view;
	    	} */
	        
	        @RequestMapping("/viewpd/{id}")
	        public ModelAndView goviewproduct(@PathVariable("id")int id) {
	        	System.out.println(id);
	        	ModelAndView view=new ModelAndView("viewproduct");
	        	view.addObject("data",pd.viewById(id));
	        	return view;
	        }


	        
	        
	        @RequestMapping("/allproduct")
	    	public ModelAndView goallproduct() {
	    	System.out.println("allproduct");
	       ModelAndView view=new ModelAndView("allproduct");
	    	view.addObject("data", pd.viewAllProduct());	
	    	return view;
	    	}
	        
	        


	        
	        
	        
	     @Autowired
			CustomerDao sd; 
	     ModelAndView m;
	     
		@ModelAttribute("obj")
		public 	Customer getCustomer(){
			return new 	Customer();
		}
		@RequestMapping("/register")
		public String goregistration() {
		System.out.println("register");
		return "register";
		}
		
		
		@RequestMapping("/save")
		public ModelAndView addC(@Valid @ModelAttribute("obj")Customer c,BindingResult br) 
		{
			if(br.hasErrors()){
				m= new ModelAndView("register");
				
				m.addObject("obj", c);
				return m;
			}
				
			m = new ModelAndView("login");
			String emailregex = "^[_A-Za-z0-9-]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9-]+)*(\\.[A-Za-z]{2,})$";
	        if(c.getEmail().matches(emailregex)&&c.getUserpassword().equals(c.getConfirmpassword()))
	        sd.addCustomer(c);
	        else{
				m= new ModelAndView("thankyou");
			    m.addObject("obj", c);
				return m;
	        }
	        return m;
		}
		
		

	
       @RequestMapping("/")
        public String profile() {
        System.out.println("index");
        return "index";
        }

        @RequestMapping("/login")
        public String profile13() {
        System.out.println("login");
        return "login";
        }

             

        @RequestMapping("/index")
        public String profile7() {
        System.out.println("index");
        return "index";
        }
        
        
        
        @RequestMapping("/contact")
        public String profile1() {
        System.out.println("contact");
        return "contact";
        }
 
        
        @RequestMapping("/electronics")
        public String profile2() {
        System.out.println("electronics");
        return "electronics";
        }
 
       
        @RequestMapping("/single")
        public String profile4() {
        System.out.println("single");
        return "single";
        }

        
        @RequestMapping("/checkout")
        public String profile5() {
        System.out.println("checkout");
        return "checkout";
        }
 
         
        @RequestMapping("/clothing")
        public String goclothing() {
        System.out.println("clothing");
        return "clothing";
        }
 
        @RequestMapping("/denied")
        public String denied() {
        System.out.println("denied");
        return "denied";
        }

        

        @RequestMapping("/thankyou")
        public String thankyou() {
        System.out.println("thankyou");
        return "thankyou";
        }
     
         

        
        @RequestMapping("/logout")
    	public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse response){
    	ModelAndView view = new ModelAndView("index");
    	request.getSession().invalidate();
    	return view;
    	}

        }



