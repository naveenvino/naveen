package productstore.controllers;

/*import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import productstore.DAO.ProductDAO;
import productstore.Model.Product;
import productstore.services.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService ps;
	
	@ModelAttribute("pobj")
	public Product getPd(){
		return new Product();
	}
	
	@RequestMapping("/addProd")
	public String gop1(){
		return "AddProduct";
	}
	
	@RequestMapping("/saveProd")
	public String gop2(@ModelAttribute("obj")Product x){
		ps.addProduct(x);
		return "addProduct";
	}
	@RequestMapping("/delProd/id")
	public String gop11(@PathVariable("id")int id){
		ps.delProduct(id);
		return "redirect:/viewall";
	}
	@RequestMapping("/updProd/id")
	public ModelAndView gop12(@PathVariable("id")int id){
		ModelAndView m= new ModelAndView("EditProduct");
		m.addObject("oldobj",ps.viewById(id));
		return m;
	}
	@RequestMapping("/updsaveProd")
	public String gop13(@ModelAttribute("oldobj")Product x){
      ps.updProduct(x);
		return "addProduct";
	}
	@RequestMapping("/viewProd/id")
	public ModelAndView gop14(@PathVariable("id")int id){
		ModelAndView m= new ModelAndView("EditProduct");
		m.addObject("obj",ps.viewById(id));
		return m;
	}
	@RequestMapping("/viewall")
	public ModelAndView gop15(){
ModelAndView m= new ModelAndView("viewAllProducts");
m.addObject("data",ps.viewAll());
		return m;
	}
}


*/