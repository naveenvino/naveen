package productstore.DAO;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import productstore.Model.Customer;
@Repository
public class CustomerDaoImpl implements CustomerDao {
@Autowired
	
	SessionFactory sf;
	
	Session s;
	Transaction t;
	Customer obj;
	

	@Override
	public void addCustomer(Customer c)  { 
		s = sf.openSession();
		t = s.beginTransaction();
		s.save(c);
		t.commit();
	}
	@Override
	public void delCustomer(String username) {
		// TODO Auto-generated method stub

	}

	@Override
	public void saveorupdCustomer(Customer p) {
		// TODO Auto-generated method stub

	}

	@Override
	public Customer viewById(String username) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Customer> viewAllCustomers() {
		// TODO Auto-generated method stub
		return null;
	}

}
