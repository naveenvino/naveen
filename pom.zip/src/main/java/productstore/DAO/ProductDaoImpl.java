package productstore.DAO;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import productstore.Model.Product;
@Repository
public class ProductDaoImpl implements ProductDao {
@Autowired
	
	SessionFactory sf;
	
	Session s;
	Transaction t;
	Product obj;

	@Override
	public void addProduct(Product c) {
		s = sf.openSession();
		t = s.beginTransaction();
		s.save(c);
		t.commit();
	}

	@Override
	public void delProduct(int id) {
		// TODO Auto-generated method stub

	}

	@Override
	public void saveorupdProduct(Product p) {
		// TODO Auto-generated method stub

	}

	@Override
	public Product viewById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Product> viewAllProduct() {
		// TODO Auto-generated method stub
		return null;
	}

}
