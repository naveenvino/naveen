package productstore.controllers;


import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import productstore.DAO.CustomerDao;
import productstore.DAO.ProductDao;
import productstore.Model.Customer;
import productstore.Model.Product;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

@Controller
public class LoginController {
		
	   
		
	     @Autowired
			ProductDao pd;
		
	     @ModelAttribute("probj")
			public 	Product getproduct(){
				return new 	Product();
			}
	     
	     @RequestMapping("/product")
			public String Product() {
			System.out.println("product");
			return "product";
			}
	     @RequestMapping("/prosave")
			public String goproSave(@ModelAttribute("probj")Product x){
				System.out.println("In proSave");
				pd.addProduct(x);
				return "thankyou";
			}
	     
	     @Autowired
			CustomerDao sd; 
	     
		@ModelAttribute("obj")
		public 	Customer getCustomer(){
			return new 	Customer();
		}
		@RequestMapping("/register")
		public String goregistration() {
		System.out.println("register");
		return "register";
		}
		
		@RequestMapping("/save")
		public String goSave(@ModelAttribute("obj")Customer x){
			System.out.println("In Save");
			sd.addCustomer(x);
			return "login";
		}
	
       @RequestMapping("/")
        public String profile() {
        System.out.println("index");
        return "index";
        }

        @RequestMapping("/login")
        public String profile13() {
        System.out.println("login");
        return "login";
        }

             
        @RequestMapping("/wallets")
        public String wallets() {
        System.out.println("wallets");
        return "wallets";
        }

        @RequestMapping("/index")
        public String profile7() {
        System.out.println("index");
        return "index";
        }
        
        @RequestMapping("/mens2")
        public String profile8() {
        System.out.println("mens2");
        return "mens2";
        }
        
       
        @RequestMapping("/mens3")
        public String profile9() {
        System.out.println("mens3");
        return "mens3";
        }
       
        @RequestMapping("/mens4")
        public String profile10() {
        System.out.println("mens4");
        return "mens4";
        }
      
        @RequestMapping("/mens5")
        public String profile11() {
        System.out.println("mens5");
        return "mens5";
        }
      
        
        
        @RequestMapping("/contact")
        public String profile1() {
        System.out.println("contact");
        return "contact";
        }
 
        
        @RequestMapping("/electronics")
        public String profile2() {
        System.out.println("electronics");
        return "electronics";
        }
 
        @RequestMapping("/mens")
        public String profile3() {
        System.out.println("mens");
        return "mens";
        }
 
       
        @RequestMapping("/single")
        public String profile4() {
        System.out.println("single");
        return "single";
        }

        
        @RequestMapping("/checkout")
        public String profile5() {
        System.out.println("checkout");
        return "checkout";
        }
 
         
        @RequestMapping("/clothing")
        public String goclothing() {
        System.out.println("clothing");
        return "clothing";
        }

        @RequestMapping("/footwear")
        public String gofootwear() {
        System.out.println("footwear");
        return "footwear";
        }
 
        @RequestMapping("/watches")
        public String gowatches() {
        System.out.println("watches");
        return "watches";
        }
 
 
        @RequestMapping("/sunglasses")
        public String sunglasses() {
        System.out.println("sunglasses");
        return "sunglasses";
        }
 
        
}



