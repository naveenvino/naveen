package controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BaseController {
	
	
	@RequestMapping("/cancelled")
    public String cancelled() {
    System.out.println("cancelled");
    return "cancelled";
    }


	@RequestMapping("/finish")
    public String finish() {
    System.out.println("finish");
    return "finish";
    }


	@RequestMapping("/")
    public String welcome() {
    System.out.println("welcome");
    return "welcome";
    }


	
	@RequestMapping("/welcome")
    public String welcome1() {
    System.out.println("welcome");
    return "welcome";
    }

}
